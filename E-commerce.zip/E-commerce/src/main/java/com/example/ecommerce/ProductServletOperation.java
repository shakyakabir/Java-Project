package com.example.ecommerce;

import com.example.ecommerce.dbconnection.ProductDao;
import com.example.ecommerce.model.Product;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@MultipartConfig
@WebServlet(name = "ProductServletOperation", value = "/ProductServletOperation")
public class ProductServletOperation extends HttpServlet {
    private String pName;
    private String pDesc;

    private int pPrice;
    private int pQuantity;
    Part file;
    String fileName;
    String uploadPath;

    public ProductServletOperation() {
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out =response.getWriter();
        pName = request.getParameter("pName");
        pDesc = request.getParameter("pDesc");
        pPrice = Integer.parseInt(request.getParameter("pPrice"));
        pQuantity = Integer.parseInt(request.getParameter("pQuantity"));
        file = request.getPart("pPic");
        fileName = file.getSubmittedFileName();
        uploadPath = "C:/Users/DELL/Desktop/javaProject/E-commerce/src/main/webapp/adminpic" + fileName;

        try {
            FileOutputStream fileOutputStream = new FileOutputStream(uploadPath);
            InputStream inputStream = file.getInputStream();
            byte[] data = new byte[inputStream.available()];
            inputStream.read(data);
            fileOutputStream.write(data);
            fileOutputStream.close();

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                String url = "jdbc:mysql://localhost:3306/add_product";
                String name = "root";
                String password = "root";
                Connection connection = DriverManager.getConnection(url, name, password);
                PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO menu(fileName,pNmae,pDesc,pPrice,pQuantity) VALUES (?,?,?,?,?)");
                preparedStatement.setString(1, fileName);
                preparedStatement.setString(2, pName);
                preparedStatement.setString(3,pDesc);
                preparedStatement.setInt(4,pPrice);
                preparedStatement.setInt(5,pQuantity);
                int i = preparedStatement.executeUpdate();
                if (i > 0) {
                    System.out.println("products are successfully added");
                } else {
                    System.out.println("products failed to add: (");
                }
            } catch (ClassNotFoundException | SQLException e) {
                System.out.println(e);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Unable to store" + e);
        }

    }
}
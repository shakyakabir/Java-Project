package com.example.ecommerce.dbconnection;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class ProductDao {
    Connection connection = null;

    public ProductDao() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/add_product";
            String name = "root";
            String password = "root";
            connection = DriverManager.getConnection(url,name,password);
            System.out.println("connection success");
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public PreparedStatement product(String query){
        PreparedStatement preparedStatement= null ;
        try {
            preparedStatement =connection.prepareStatement(query);
            return preparedStatement;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

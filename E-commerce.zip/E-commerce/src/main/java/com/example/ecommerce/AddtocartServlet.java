package com.example.ecommerce;

import com.example.ecommerce.model.Cart;
import com.mysql.cj.xdevapi.Session;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;

@WebServlet(name = "AddtocartServlet", value = "/AddtocartServlet")
public class AddtocartServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType("text/Html;charset=UTF-8");

    try(PrintWriter out=response.getWriter()){
        ArrayList<Cart> cartList =new ArrayList<>();
         int id=Integer.parseInt(request.getParameter("Id"));
         Cart cr =new Cart();
         cr.setId(id);
         cr.setQuantity(1);

         HttpSession session=request.getSession();
       ArrayList<Cart> cart_list = (ArrayList<Cart>) session.getAttribute("cart-list");

       if(cart_list == null){
           cartList.add(cr);
           session.setAttribute("cart-list", cartList);
           out.println("session created and added");
       }else {
           cartList = cart_list;
           boolean exist=false;
           for(Cart c:cart_list){
               if(c.getId()==id){
                   exist=true;
                   out.println("product exist in cart");
               }
               if (!exist){
                   cartList.add(cr);
                   out.println("product add");
               }
           }
       }
       for (Cart c:cart_list){
          response.sendRedirect("home.jsp");
       }


     }
    }
}
package com.example.ecommerce;

import com.example.ecommerce.dbconnection.DBConnection;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet(name = "loginServlet", value = "/loginServlet")
public class loginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String dbemail=null;
        String dbpss=null;
        String email=request.getParameter("email");
        String password=request.getParameter("password");
        System.out.println(email);
        try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/e_commerce", "root", "root");
             // Step 2:Create a statement using connection object
             Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery("SELECT * from register_user");
             while (rs.next()){
                 if(email.equals(rs.getString("email")) && password.equals(rs.getString("password"))){
                    dbemail=rs.getString("email");
                    dbpss= rs.getString("password");

                 break;
                 }
             }
            System.out.println(dbemail);
             if (email.equals(dbemail) && password.equals(dbpss)){
                 RequestDispatcher dispatcher=request.getRequestDispatcher("pages/home.jsp");
                 dispatcher.forward(request,response);
                 System.out.println("you sucessful enter");
             }else {
                 response.setContentType("Text/Html");
                 PrintWriter out= response.getWriter();
                 String msc="invalid password";
                 out.print(msc);
                 RequestDispatcher dispatcher=request.getRequestDispatcher("pages/login.jsp");
                 dispatcher.include(request,response);
             }
//            if ("admin@gmail.com".equals(email) && "dell".equals(password)) {
//                // Admin login successful
//                RequestDispatcher dispatcher = request.getRequestDispatcher("/page/admin.jsp");
//                dispatcher.forward(request, response);
//            } else {
//                // Invalid admin credentials
//                response.setContentType("text/html");
//                PrintWriter out = response.getWriter();
//                String message = "Invalid admin credentials";
//                out.print(message);
//                RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
//                dispatcher.include(request, response);
//            }



        } catch (SQLException | ClassNotFoundException e) {
            // process sql exception
            System.out.println(e);
        }





            }
            }



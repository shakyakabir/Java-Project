package com.example.ecommerce.model;

public class Cart extends Userproduct{
    private int Quantity;


    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }


}
